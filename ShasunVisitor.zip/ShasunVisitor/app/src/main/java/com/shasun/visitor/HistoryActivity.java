package com.shasun.visitor;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;

public class HistoryActivity extends AppCompatActivity {
    private static String ResultString = "";
    TextView txtFromDate,txtToDate;
    ImageButton ibSearch;
    RecyclerView mRecyclerView;                           // Declaring RecyclerView
    RecyclerView.LayoutManager mLayoutManager;            // Declaring Layout Manager as a linear layout manager
    private final ArrayList<String> leavestatus_list = new ArrayList<String>(200);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        ibSearch = findViewById(R.id.ibSearch);
        txtFromDate = findViewById(R.id.txtFromDate);
        txtFromDate.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                // TODO Auto-generated method stub
                Calendar mcurrentDate=Calendar.getInstance();
                int mYear=mcurrentDate.get(Calendar.YEAR);
                int mMonth=mcurrentDate.get(Calendar.MONTH);
                int mDay=mcurrentDate.get(Calendar.DAY_OF_MONTH);

                final DatePickerDialog mDatePicker=new DatePickerDialog(HistoryActivity.this, new DatePickerDialog.OnDateSetListener(){
                    public void onDateSet(DatePicker datepicker, int selectedYear, int selectedMonth, int selectedDay){
                        // TODO Auto-generated method stub
                        /*      Your code   to get date and time    */

                        String year1 = String.valueOf(selectedYear);
                        String month1 = String.valueOf(selectedMonth + 1);
                        String day1 = String.valueOf(selectedDay);
                        txtFromDate.setText(day1 + "/" + month1 + "/" + year1);
                        txtFromDate.setTag(day1 + "-" + month1 + "-" + year1);

                    }
                },mYear, mMonth, mDay);
                mDatePicker.setTitle("Select From Date");
                mDatePicker.getDatePicker().setMaxDate(System.currentTimeMillis());
                mDatePicker.show();
            }
        });
        txtToDate = findViewById(R.id.txtToDate);
        txtToDate.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                // TODO Auto-generated method stub
                Calendar mcurrentDate=Calendar.getInstance();
                int mYear=mcurrentDate.get(Calendar.YEAR);
                int mMonth=mcurrentDate.get(Calendar.MONTH);
                int mDay=mcurrentDate.get(Calendar.DAY_OF_MONTH);

                final DatePickerDialog mDatePicker=new DatePickerDialog(HistoryActivity.this, new DatePickerDialog.OnDateSetListener(){
                    public void onDateSet(DatePicker datepicker, int selectedYear, int selectedMonth, int selectedDay){
                        // TODO Auto-generated method stub
                        /*      Your code   to get date and time    */

                        String year1 = String.valueOf(selectedYear);
                        String month1 = String.valueOf(selectedMonth + 1);
                        String day1 = String.valueOf(selectedDay);
                        txtToDate.setText(day1 + "/" + month1 + "/" + year1);
                        txtToDate.setTag(day1 + "-" + month1 + "-" + year1);

                    }
                },mYear, mMonth, mDay);
                mDatePicker.setTitle("Select From Date");
                mDatePicker.getDatePicker().setMaxDate(System.currentTimeMillis());
                mDatePicker.show();
            }
        });


        Calendar mcurrentDate=Calendar.getInstance();
        int mYear=mcurrentDate.get(Calendar.YEAR);
        int mMonth=mcurrentDate.get(Calendar.MONTH);
        mMonth = mMonth+1;
        int mDay=mcurrentDate.get(Calendar.DAY_OF_MONTH);
        txtFromDate.setText(mDay + "/" + mMonth + "/" + mYear);
        txtFromDate.setTag(mDay + "-" + mMonth + "-" + mYear);
        txtToDate.setText(mDay + "/" + mMonth + "/" + mYear);
        txtToDate.setTag(mDay + "-" + mMonth + "-" + mYear);



        WebService.strParameters = new String[]{"String", "fromdate", txtFromDate.getTag().toString(), "String", "todate", txtToDate.getTag().toString()};
        WebService.METHOD_NAME = "getVisitorDetails";
        AsyncCallWS task = new AsyncCallWS();
        task.execute();
        ibSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                WebService.strParameters = new String[]{"String", "fromdate", txtFromDate.getTag().toString(), "String", "todate", txtToDate.getTag().toString()};
                WebService.METHOD_NAME = "getVisitorDetails";
                AsyncCallWS task = new AsyncCallWS();
                task.execute();
            }
        });
    }
    private void displayLeaveStatus() {
        leavestatus_list.clear();
        try {
            JSONArray temp = new JSONArray(ResultString);
            // Log.i("TEST: ",ResultString.toString());
            for (int i = 0; i <= temp.length() - 1; i++) {
                JSONObject object = new JSONObject(temp.getJSONObject(i).toString());
                leavestatus_list.add(object.getString("applicationdate") + "##" +
                        object.getString("leavetype") + "##" + object.getString("fromdate") + "##" +
                        object.getString("todate") + "##" + object.getString("session") + "##" +
                        object.getString("reason") + "##" + object.getString("noofdays") + "##" +
                        object.getString("leavestatus") + "##" + object.getString("leaveapplicationid"));

            }
            if (leavestatus_list.size() == 0) {
                Toast.makeText(HistoryActivity.this, "Response: No Data Found", Toast.LENGTH_LONG).show();
            } else {
                mRecyclerView = findViewById(R.id.rvLeaveStatus); // Assigning the RecyclerView Object to the xml View
                mRecyclerView.setHasFixedSize(true);
                // Letting the system know that the list objects are of fixed size
                LeaveStatusLVAdapter TVA = new LeaveStatusLVAdapter(leavestatus_list, R.layout.leavestatuslistitem);
                mRecyclerView.setAdapter(TVA);
                mLayoutManager = new LinearLayoutManager(this);                 // Creating a layout Manager
                mRecyclerView.setLayoutManager(mLayoutManager);                 // Setting the layout Manager
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            Toast.makeText(HistoryActivity.this, "Response: "+ResultString, Toast.LENGTH_LONG).show();
        }


    }

    private class AsyncCallWS extends AsyncTask<Void, Void, Void> {
        ProgressDialog dialog = new ProgressDialog(HistoryActivity.this);

        @Override
        protected void onPreExecute() {
            dialog.setMessage(getResources().getString(R.string.loading));
            //show dialog
            dialog.show();
            //Log.i(TAG, "onPreExecute");
        }

        @Override
        protected Void doInBackground(Void... params) {
            //Log.i(TAG, "doInBackground");
            if (android.os.Debug.isDebuggerConnected())
                android.os.Debug.waitForDebugger();
            ResultString = WebService.invokeWS();
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            //Log.i(TAG, "onPostExecute");
            if (dialog != null && dialog.isShowing()) {
                dialog.dismiss();
            }
            displayLeaveStatus();
            Toast.makeText(HistoryActivity.this, "Response: " + ResultString, Toast.LENGTH_LONG).show();


        }
    }

}