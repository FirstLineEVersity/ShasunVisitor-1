package com.shasun.visitor;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {
    Button btnTakePhoto,btnSave;
    ImageView imageView;
    public static final int RequestPermissionCode = 1;
    TextInputEditText txtVisitorName,txtMobile,txtAddress,txtStudentName,txtDivision;

    private static String ResultString = "";
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //toolbar = findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);

        btnTakePhoto = findViewById(R.id.buttonTake);
        btnSave = findViewById(R.id.btnSave);
        imageView = findViewById(R.id.imageView);
        txtVisitorName = findViewById(R.id.txtVisitorName);
        txtMobile = findViewById(R.id.txtMobile);
        txtAddress = findViewById(R.id.txtAddress);
        txtStudentName = findViewById(R.id.txtMsg);
        //txtDivision = findViewById(R.id.txtDivision);
        EnableRuntimePermission();
        btnTakePhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, 7);
            }
        });
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveData();
            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 7 && resultCode == RESULT_OK) {
            Bitmap bitmap = (Bitmap) data.getExtras().get("data");
            imageView.setImageBitmap(bitmap);
        }
    }

    public void saveData(){
        if(txtVisitorName.getText().toString().length() < 1){
            dataRequired("Please Enter Visitor Name");
        }else if(txtMobile.getText().toString().length() < 1){
            dataRequired("Please Enter Visitor Mobile Number");
        }else if(txtAddress.getText().toString().length() < 1){
            dataRequired("Please Enter Visitor Address");
        }else if(txtStudentName.getText().toString().length() < 1){
            dataRequired("Please Enter Student Name");
        }else if(txtDivision.getText().toString().length() < 1){
            dataRequired("Please Enter Student department");
        }else {

            //WebService.strParameters = new String[]{"Long", "programsectionid", String.valueOf(lngProgSecId), "string", "attendancedate", strAttendanceDate};
            WebService.METHOD_NAME = "saveVisitorData";
            AsyncCallWS task = new AsyncCallWS();
            task.execute();
        }

    }

    private class AsyncCallWS extends AsyncTask<Void, Void, Void> {
        ProgressDialog dialog = new ProgressDialog(MainActivity.this);

        @Override
        protected void onPreExecute() {
            dialog.setMessage(getResources().getString(R.string.loading));
            //show dialog
            dialog.show();
            //Log.i(TAG, "onPreExecute");
        }

        @Override
        protected Void doInBackground(Void... params) {
            //Log.i(TAG, "doInBackground");
            if (android.os.Debug.isDebuggerConnected())
                android.os.Debug.waitForDebugger();
            ResultString = WebService.invokeWS();
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            //Log.i(TAG, "onPostExecute");
            if (dialog != null && dialog.isShowing()) {
                dialog.dismiss();
            }
            Toast.makeText(MainActivity.this, "Response: " + ResultString, Toast.LENGTH_LONG).show();


        }
    }

    public void dataRequired(String text){
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
        return;
    }
    public void EnableRuntimePermission(){
        if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,
                Manifest.permission.CAMERA)) {
            Toast.makeText(MainActivity.this,"CAMERA permission allows us to Access CAMERA app",     Toast.LENGTH_LONG).show();
        } else {
            ActivityCompat.requestPermissions(MainActivity.this,new String[]{
                    Manifest.permission.CAMERA}, RequestPermissionCode);
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] result) {
        super.onRequestPermissionsResult(requestCode, permissions, result);
        switch (requestCode) {
            case RequestPermissionCode:
                if (result.length > 0 && result[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(MainActivity.this, "Permission Granted, Now your application can access CAMERA.", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(MainActivity.this, "Permission Canceled, Now your application cannot access CAMERA.", Toast.LENGTH_LONG).show();
                }
                break;
        }
    }
}